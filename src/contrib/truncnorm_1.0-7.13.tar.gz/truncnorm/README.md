# truncnorm
R package implementing density, probability, quantile and random number generation functions for the truncated normal distribution.

## Install from github

Run this in R to install the current GitHub version (requires the `devtools`
package):

```splus
library("devtools")
install_github("olafmersmann/truncnorm")
```

[![CRAN Status Badge](http://www.r-pkg.org/badges/version/truncnorm)](http://cran.r-project.org/web/packages/truncnorm)
[![CRAN Downloads](http://cranlogs.r-pkg.org/badges/truncnorm)](http://cran.rstudio.com/web/packages/truncnorm/index.html)

