if (require("testthat"))
  test_check("truncnorm")
