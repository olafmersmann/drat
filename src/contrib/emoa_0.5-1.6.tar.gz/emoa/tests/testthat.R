library("testthat")
test_check("emoa")
