if (require("testthat"))
  test_check("soobench")
