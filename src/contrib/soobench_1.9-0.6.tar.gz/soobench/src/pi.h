#ifndef __PI_H__
#define __PI_H__

#include <math.h>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#endif
